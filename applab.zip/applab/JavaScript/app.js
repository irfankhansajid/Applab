// var name = 'Irfan khan'

// console.log(name);
// console.log(typeof name);


// var something;
// var anything = null;

// console.log(undefined === null);
// console.log(100  === '100');


// var age = 18

// if (age >= 18) {
//     console.log('Yes, I am Eligiable');
    
// } else {
//     console.log('No');
    
// }


// var name = 'Irfan khan'

// for(var i=0; i<10; i++) {
//     console.log('Hello, '+ name);
    
// }


// var names = [];

// names[0] = 'Irfan';
// names[1] = 'Khan';
// names[2] = 'Sajid'

// console.log(names);

// for (var i = 0; i<names.length; i++) {
//     console.log('Hello, ' + names[i].toUpperCase());
    
// }

var names = ['Irfan','Khan', 'Sajid'];
console.log(names.length);
console.log(names[names.length - 1]);

console.log(names.indexOf('Sajid'));

