$(document).ready(function(){
    var mixer = mixitup('.work-img');
});